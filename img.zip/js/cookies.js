import { shop,  menu  } from "/js/initialData.js";
import { printProducts, PrintMenu, printOneProduct } from "/js/function.js";

PrintMenu(menu);
printOneProduct(1, shop);