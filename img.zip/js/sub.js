import {  menu  } from "/js/initialData.js";
import { PrintMenu, getItFresh } from "/js/function.js";

PrintMenu(menu);
getItFresh();