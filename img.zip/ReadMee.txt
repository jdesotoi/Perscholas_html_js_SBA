If you try to run without a server will not work.

Installation
requirements
	Visual Studio Code
	Live Server Plugin for VS Code

Open the folder in Visual Studio Code.

Right-click on index.html 
 	then click Open with Live Server